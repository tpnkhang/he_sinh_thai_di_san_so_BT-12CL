using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using BepInEx;
using HarmonyLib;
using UnityEngine;
using UnityEngine.UI;

namespace HIFModMenu
{
    [BepInPlugin("com.thanhsama.hifmodmenu", "Happy Island Fantasy Super Mod Menu", "7.1.0")]
    public class HIFModMenuPlugin : BaseUnityPlugin
    {
        private bool _showMenu = false;
        private bool _showCornerBtn = true;
        private int _tab = 0;
        private Rect _windowRect = new Rect(25f, 25f, 680f, 700f);
        private Vector2 _scroll = Vector2.zero;

        private readonly string[] _tabs = new string[]
        {
            "Gallery & Full Save",
            "Nhiem Vu & Tele",
            "Hack Tien (Chuan)",
            "Give Do (TV)",
            "ESP & 4K UI"
        };

        private class MemorySlot
        {
            public object Owner;
            public string Path;
            public FieldInfo Field;
            public PropertyInfo Prop;
            public IDictionary Dict;
            public object DictKey;
            public IList List;
            public int ListIndex = -1;
            public bool IsFrozen;
            public object FrozenVal;

            public Type SlotType
            {
                get
                {
                    if (Field != null) return Field.FieldType;
                    if (Prop != null) return Prop.PropertyType;
                    if (Dict != null && DictKey != null && Dict[DictKey] != null) return Dict[DictKey].GetType();
                    if (List != null && ListIndex >= 0 && ListIndex < List.Count && List[ListIndex] != null) return List[ListIndex].GetType();
                    return typeof(int);
                }
            }

            public object Read()
            {
                try
                {
                    if (Field != null) return Field.GetValue(Owner);
                    if (Prop != null && Prop.CanRead) return Prop.GetValue(Owner, null);
                    if (Dict != null && DictKey != null) return Dict[DictKey];
                    if (List != null && ListIndex >= 0 && ListIndex < List.Count) return List[ListIndex];
                }
                catch { }
                return null;
            }

            public void Write(object val)
            {
                try
                {
                    Type t = SlotType;
                    object converted = Convert.ChangeType(val, t);
                    if (Field != null) Field.SetValue(Owner, converted);
                    else if (Prop != null && Prop.CanWrite) Prop.SetValue(Owner, converted, null);
                    else if (Dict != null && DictKey != null) Dict[DictKey] = converted;
                    else if (List != null && ListIndex >= 0 && ListIndex < List.Count) List[ListIndex] = converted;
                }
                catch { }
            }
        }

        private class ActiveQuestEntry
        {
            public string Title;
            public string Description;
            public string MissingSummary;
            public object SourceObj;
            public List<Transform> MatchingMapObjects = new List<Transform>();
            public List<MemorySlot> ProgressSlots = new List<MemorySlot>();
        }

        private class BagSlotEntry
        {
            public string RawName;
            public string VietName;
            public int ItemId;
            public MemorySlot CountSlot;
            public object ItemObj;
        }

        private class MethodCallEntry
        {
            public object Target;
            public MethodInfo Method;
            public string Signature;
        }

        private List<MemorySlot> _allNumericSlots = new List<MemorySlot>();
        private List<MemorySlot> _matchedMoneySlots = new List<MemorySlot>();
        private List<BagSlotEntry> _bagSlots = new List<BagSlotEntry>();
        private List<ActiveQuestEntry> _activeQuests = new List<ActiveQuestEntry>();
        private List<MethodCallEntry> _gameMethods = new List<MethodCallEntry>();
        private List<MethodCallEntry> _saveMethods = new List<MethodCallEntry>();
        private List<MethodCallEntry> _galleryUnlockMethods = new List<MethodCallEntry>();

        private string _exactSearchStr = "500";
        private string _targetMoneyStr = "999999";
        private string _giveAmountStr = "99";
        private int _giveAmount = 99;
        private string _bagSearchFilter = "";

        private bool _autoUnlockGalleryUIEveryFrame = false;
        private bool _forceAllGalleryUnlockedHook = false;
        private bool _freeShoppingHook = false;
        private bool _clickTeleportMode = false;
        private bool _noClipWalkThroughWalls = false;
        private int _targetSaveSlot = 1;
        private string _saveSlotInput = "1";

        private struct VietItemCat
        {
            public string VietTitle;
            public string[] Keywords;
            public int[] CandidateIds;
            public VietItemCat(string title, string[] kw, int[] ids)
            {
                VietTitle = title;
                Keywords = kw;
                CandidateIds = ids;
            }
        }

        private List<VietItemCat> _vietCategories = new List<VietItemCat>();

        private class EspNode
        {
            public Transform Trans;
            public string VietName;
            public Color Color;
            public bool IsQuestTarget;
            public bool IsNpc;
        }

        private bool _enableEsp = false;
        private bool _espLines = true;
        private float _espTimer = 0f;
        private float _uiUnlockTimer = 0f;
        private List<EspNode> _espNodes = new List<EspNode>();
        private string _espFilter = "";

        private bool _enable4K = false;
        private float _timeScale = 1.0f;
        private bool _lockSpeed = false;
        private bool _hideUi = false;
        private List<Canvas> _hiddenCanvases = new List<Canvas>();

        private Texture2D _whiteTex;
        private GUIStyle _headerStyle;
        private GUIStyle _subHeaderStyle;
        private GUIStyle _boxStyle;
        private GUIStyle _espStyle;
        private bool _stylesReady = false;

        private string _status = "San sang! (v7.1 Fix loi load mai trong Gallery). Nhan F9 mo Menu | F6 xuat Class.";

        private void Awake()
        {
            InitVietCategories();
            Logger.LogInfo("[HIF Super Mod Menu v7.1] Loaded!");
        }

        private void InitVietCategories()
        {
            _vietCategories.Add(new VietItemCat("Vang / Tien Xu (Gold / Coin / Money)", new string[] { "gold", "coin", "money", "cash", "jinbi", "qian", "currency", "wealth" }, new int[] { 0, 1, 2, 100, 1000, 1001 }));
            _vietCategories.Add(new VietItemCat("Go / Cui / Cay (Wood / Timber / Log)", new string[] { "wood", "timber", "log", "branch", "mucai", "tree", "plank" }, new int[] { 10, 11, 101, 102, 201, 1001, 2001 }));
            _vietCategories.Add(new VietItemCat("Da / Quang Da (Stone / Rock / Ore)", new string[] { "stone", "rock", "ore", "pebble", "shitou", "kuang" }, new int[] { 12, 13, 103, 104, 202, 1002, 2002 }));
            _vietCategories.Add(new VietItemCat("Sat / Thoi Sat (Iron / Metal / Ingot)", new string[] { "iron", "metal", "steel", "ingot", "tie" }, new int[] { 14, 15, 105, 106, 203, 1003, 2003 }));
            _vietCategories.Add(new VietItemCat("Thao Duoc / Hoa / Nam (Herb / Flower / Mushroom)", new string[] { "herb", "flower", "grass", "plant", "mushroom", "berry", "caoyao" }, new int[] { 16, 17, 107, 204, 1004, 2004 }));
            _vietCategories.Add(new VietItemCat("Vo So / San Ho / Ngoc Trai (Shell / Coral / Pearl)", new string[] { "shell", "coral", "pearl", "clam", "beike" }, new int[] { 18, 19, 108, 205, 1005, 2005 }));
            _vietCategories.Add(new VietItemCat("Ca / Tom / Cua Bien (Fish / Crab / Shrimp)", new string[] { "fish", "crab", "shrimp", "lobster", "seafood", "yu" }, new int[] { 20, 21, 22, 301, 302, 3001 }));
            _vietCategories.Add(new VietItemCat("Nguyen Lieu Nau An / Dau Phu (Tofu / Meat / Egg / Rice)", new string[] { "tofu", "mapo", "meat", "egg", "milk", "rice", "flour", "sugar", "salt", "spice", "food" }, new int[] { 30, 31, 32, 401, 402, 4001 }));
            _vietCategories.Add(new VietItemCat("Cong Thuc Nau An Bi Mat (Missing Recipes / Cookbook)", new string[] { "recipe", "cookbook", "mapo", "shipu", "formula", "menu" }, new int[] { 40, 41, 42, 501, 502, 503, 5001 }));
            _vietCategories.Add(new VietItemCat("Manh Nu Than / Co Vat (Goddess Fragment / Relic)", new string[] { "fragment", "goddess", "relic", "artifact", "statue", "suipian", "treasure" }, new int[] { 50, 51, 52, 601, 602, 6001 }));
            _vietCategories.Add(new VietItemCat("Qua Tang Nhan Vat Nu (Gift / Perfume / Ring / Chocolate)", new string[] { "gift", "present", "perfume", "ring", "necklace", "chocolate", "cake", "wine", "liwu" }, new int[] { 60, 61, 62, 701, 702, 7001 }));
            _vietCategories.Add(new VietItemCat("Cong Cu Riu / Cuoc / Can Cau (Axe / Pickaxe / Rod)", new string[] { "axe", "pickaxe", "rod", "fishing", "shovel", "hammer", "tool" }, new int[] { 70, 71, 72, 801, 802, 8001 }));
            _vietCategories.Add(new VietItemCat("Vat Pham Nhiem Vu / Chia Khoa / Meo (Quest / Key / Cat)", new string[] { "quest", "key", "cat", "thief", "letter", "map", "pass", "ticket", "renwu", "mao" }, new int[] { 80, 81, 82, 901, 902, 9001 }));
        }

        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.F9)) _showMenu = !_showMenu;
            if (Input.GetKeyDown(KeyCode.F7))
            {
                _enableEsp = !_enableEsp;
                if (_enableEsp) ScanEspTargets();
                _status = _enableEsp ? "Da BAT ESP (F7)!" : "Da TAT ESP (F7).";
            }
            if (Input.GetKeyDown(KeyCode.F6)) ExportExactClassStructure();
            if (Input.GetKeyDown(KeyCode.F10)) ToggleUI();

            if ((_clickTeleportMode && Input.GetMouseButtonDown(1)) || ((Input.GetKey(KeyCode.LeftAlt) || Input.GetKey(KeyCode.RightAlt)) && Input.GetMouseButtonDown(0)))
            {
                Camera cam = Camera.main;
                if (cam != null)
                {
                    Vector3 mp = Input.mousePosition;
                    mp.z = Mathf.Abs(cam.transform.position.z);
                    TeleportPlayerTo(cam.ScreenToWorldPoint(mp));
                }
            }

            if (_lockSpeed) Time.timeScale = _timeScale;
            if (_enable4K && (Screen.width != 3840 || Screen.height != 2160))
            {
                Screen.SetResolution(3840, 2160, FullScreenMode.FullScreenWindow);
            }

            if (_enableEsp)
            {
                _espTimer += Time.unscaledDeltaTime;
                if (_espTimer >= 1.5f) { _espTimer = 0f; ScanEspTargets(); }
            }

            if (_autoUnlockGalleryUIEveryFrame)
            {
                _uiUnlockTimer += Time.unscaledDeltaTime;
                if (_uiUnlockTimer >= 0.5f) { _uiUnlockTimer = 0f; ForceUnlockAllCurrentUIButtons(); }
            }

            for (int i = 0; i < _matchedMoneySlots.Count; i++)
            {
                if (_matchedMoneySlots[i].IsFrozen && _matchedMoneySlots[i].FrozenVal != null)
                    _matchedMoneySlots[i].Write(_matchedMoneySlots[i].FrozenVal);
            }
            for (int i = 0; i < _allNumericSlots.Count; i++)
            {
                if (_allNumericSlots[i].IsFrozen && _allNumericSlots[i].FrozenVal != null)
                    _allNumericSlots[i].Write(_allNumericSlots[i].FrozenVal);
            }
        }

        private void InitStyles()
        {
            if (_stylesReady) return;
            _headerStyle = new GUIStyle(GUI.skin.label);
            _headerStyle.fontStyle = FontStyle.Bold;
            _headerStyle.fontSize = 13;
            _headerStyle.normal.textColor = new Color(1f, 0.88f, 0.3f);

            _subHeaderStyle = new GUIStyle(GUI.skin.label);
            _subHeaderStyle.fontStyle = FontStyle.Bold;
            _subHeaderStyle.fontSize = 12;
            _subHeaderStyle.normal.textColor = new Color(0.5f, 1f, 0.65f);

            _boxStyle = new GUIStyle(GUI.skin.box);
            _boxStyle.padding = new RectOffset(8, 8, 8, 8);

            _espStyle = new GUIStyle(GUI.skin.label);
            _espStyle.fontStyle = FontStyle.Bold;
            _espStyle.fontSize = 13;
            _espStyle.alignment = TextAnchor.MiddleCenter;

            _whiteTex = new Texture2D(1, 1);
            _whiteTex.SetPixel(0, 0, Color.white);
            _whiteTex.Apply();

            _stylesReady = true;
        }

        private void OnGUI()
        {
            InitStyles();

            if (_enableEsp && Event.current.type == EventType.Repaint) DrawEspOverlay();

            if (_showCornerBtn && !_showMenu)
            {
                if (GUI.Button(new Rect(10f, 10f, 165f, 30f), "Mod Menu v7.1 (F9)"))
                {
                    _showMenu = true;
                }
            }

            if (!_showMenu) return;

            _windowRect = GUI.Window(889908, _windowRect, DrawWindow, "Happy Island Fantasy - Super Mod Menu v7.1 [F9 | F6: Xuat Class]");
        }

        private void DrawWindow(int id)
        {
            GUILayout.BeginVertical();
            _tab = GUILayout.Toolbar(_tab, _tabs);
            GUILayout.Space(6f);

            _scroll = GUILayout.BeginScrollView(_scroll, GUILayout.Height(565f));
            switch (_tab)
            {
                case 0: DrawGalleryAndFullSaveTab(); break;
                case 1: DrawQuestTrackerAndTeleTab(); break;
                case 2: DrawMoneyHackTab(); break;
                case 3: DrawGiveItemsTab(); break;
                case 4: DrawSceneAndGraphicsTab(); break;
            }
            GUILayout.EndScrollView();

            GUILayout.Space(4f);
            GUILayout.Label("Trang thai: " + _status);

            GUILayout.BeginHorizontal();
            _showCornerBtn = GUILayout.Toggle(_showCornerBtn, "Nut goc man hinh");
            if (GUILayout.Button("Xuat Class Game (F6)", GUILayout.Width(150f))) ExportExactClassStructure();
            if (GUILayout.Button("An Menu (F9)", GUILayout.Width(105f))) _showMenu = false;
            GUILayout.EndHorizontal();

            GUILayout.EndVertical();
            GUI.DragWindow(new Rect(0f, 0f, 10000f, 26f));
        }

        // ==================== TAB 0: GALLERY & FULL SAVE (FIXED LOAD FOREVER) ====================
        private void DrawGalleryAndFullSaveTab()
        {
            GUILayout.BeginVertical(_boxStyle);
            GUILayout.Label("1. Mo Khoa Gallery / Ky Niem (Da Fix Loi Load Mai Khong Xem Duoc)", _headerStyle);
            GUILayout.Label("Luu y quan trong: Khong sua cac co trang thai Load Scene nua! Chi mo khoa du lieu Gallery/CG va them nut Xuat Danh Sach Class (F6) neu can xem ten ham chinh xac.");

            GUILayout.Space(4f);
            if (GUILayout.Button("★ MO KHOA GALLERY CHUAN (CHI DUNG BIEN GALLERY/CG, KHONG KET LOAD) ★", GUILayout.Height(38f)))
            {
                UnlockGalleryCleanly();
            }

            GUILayout.Space(4f);
            _autoUnlockGalleryUIEveryFrame = GUILayout.Toggle(_autoUnlockGalleryUIEveryFrame, "Tu dong go O Khoa UI trong bang 'Ky niem'");

            GUILayout.BeginHorizontal();
            if (GUILayout.Button("Go O Khoa Tren Man Hinh")) ForceUnlockAllCurrentUIButtons();
            if (GUILayout.Button("★ Xuat Ten Class Gallery/Tien/Tui Do (F6) ★")) ExportExactClassStructure();
            GUILayout.EndHorizontal();
            GUILayout.EndVertical();

            GUILayout.Space(8f);

            GUILayout.BeginVertical(_boxStyle);
            GUILayout.Label("2. Tao File Save 100% Full Tat Ca Nhiem Vu + Max Tien + Full Gallery", _headerStyle);
            GUILayout.Label("Hay vao trong game (bam 'Tiep tuc' hoac 'Tai' save dang choi) roi bam nut duoi day:");

            GUILayout.Space(4f);
            GUILayout.BeginHorizontal();
            GUILayout.Label("Slot Save (1-10):", GUILayout.Width(115f));
            _saveSlotInput = GUILayout.TextField(_saveSlotInput, GUILayout.Width(50f));
            int.TryParse(_saveSlotInput, out _targetSaveSlot);
            if (_targetSaveSlot < 0) _targetSaveSlot = 1;

            if (GUILayout.Button("★ BOM 100% FULL NHIEM VU + TIEN + GALLERY & GHI SAVE ★", GUILayout.Height(38f)))
            {
                GenerateAndWrite100PercentSaveFileSafe(_targetSaveSlot);
            }
            GUILayout.EndHorizontal();

            GUILayout.Space(4f);
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("Sao Luu (Backup) File Save Goc")) BackupExistingSaveFiles();
            if (GUILayout.Button("Khoi Phuc (Restore) File Save Goc")) RestoreBackupSaveFiles();
            GUILayout.EndHorizontal();
            GUILayout.EndVertical();
        }

        private void UnlockGalleryCleanly()
        {
            if (_allNumericSlots.Count == 0) ScanEverythingInGame();
            int unlockedCount = 0;

            // ONLY touch explicit Gallery / CG / Memory / FreeH fields (never touch 'open'/'scene'/'event'/'clear' which break scene loading!)
            string[] strictGalKeys = new string[]
            {
                "gallery", "cg", "memory", "memories", "recall", "replay", "freeh", "hscene",
                "huilang", "huiyi", "jiesuo", "album", "unlockcg", "unlockall", "unlockmemory"
            };

            for (int i = 0; i < _allNumericSlots.Count; i++)
            {
                MemorySlot ms = _allNumericSlots[i];
                string low = ms.Path.ToLower();

                // Never modify loading/coroutine/state flags!
                if (low.Contains("load") || low.Contains("async") || low.Contains("bundle") || low.Contains("wait"))
                    continue;

                bool match = false;
                for (int k = 0; k < strictGalKeys.Length; k++)
                {
                    if (low.Contains(strictGalKeys[k])) { match = true; break; }
                }
                if (!match) continue;

                if (ms.SlotType == typeof(bool))
                {
                    bool setVal = !(low.EndsWith("lock") || low.EndsWith("locked"));
                    ms.Write(setVal);
                    unlockedCount++;
                }
                else if (ms.SlotType == typeof(int))
                {
                    object cur = ms.Read();
                    if (cur is int && (int)cur == 0)
                    {
                        ms.Write(1);
                        unlockedCount++;
                    }
                }
            }

            // Also call zero-arg or bool-arg Unlock methods on Gallery/Memory classes ONLY
            for (int i = 0; i < _galleryUnlockMethods.Count; i++)
            {
                MethodCallEntry gm = _galleryUnlockMethods[i];
                ParameterInfo[] ps = gm.Method.GetParameters();
                try
                {
                    if (ps.Length == 0) { gm.Method.Invoke(gm.Target, null); unlockedCount++; }
                    else if (ps.Length == 1 && ps[0].ParameterType == typeof(bool)) { gm.Method.Invoke(gm.Target, new object[] { true }); unlockedCount++; }
                }
                catch { }
            }

            ForceUnlockAllCurrentUIButtons();
            _status = string.Format("Da mo khoa sach se {0} bien Gallery! Neu bam xem van load mai, hay bam F6 gui file HIF_Exact_Classes.txt cho minh nha!", unlockedCount);
        }

        private void ExportExactClassStructure()
        {
            try
            {
                Assembly gameAsm = FindAssemblyByName("Assembly-CSharp");
                if (gameAsm == null)
                {
                    _status = "Khong tim thay Assembly-CSharp!";
                    return;
                }

                StringBuilder sb = new StringBuilder();
                sb.AppendLine("=== HAPPY ISLAND FANTASY EXACT CLASS & METHOD STRUCTURE ===");
                Type[] types = gameAsm.GetTypes();
                string[] interesting = new string[]
                {
                    "gallery", "cg", "memory", "recall", "freeh", "hscene", "save", "data",
                    "player", "money", "gold", "coin", "item", "bag", "inv", "quest", "task", "mission", "unlock", "cheat"
                };

                for (int i = 0; i < types.Length; i++)
                {
                    Type t = types[i];
                    string tn = t.Name.ToLower();
                    bool match = false;
                    for (int k = 0; k < interesting.Length; k++)
                    {
                        if (tn.Contains(interesting[k])) { match = true; break; }
                    }
                    if (!match) continue;

                    sb.AppendLine("\n[CLASS] " + t.FullName);
                    FieldInfo[] fs = t.GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly);
                    for (int f = 0; f < Math.Min(fs.Length, 25); f++)
                    {
                        sb.AppendLine("  Field: " + fs[f].FieldType.Name + " " + fs[f].Name);
                    }
                    MethodInfo[] ms = t.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly);
                    for (int m = 0; m < Math.Min(ms.Length, 25); m++)
                    {
                        if (ms[m].Name.StartsWith("get_") || ms[m].Name.StartsWith("set_")) continue;
                        ParameterInfo[] ps = ms[m].GetParameters();
                        string pStr = "";
                        for (int p = 0; p < ps.Length; p++)
                        {
                            pStr += (p > 0 ? ", " : "") + ps[p].ParameterType.Name + " " + ps[p].Name;
                        }
                        sb.AppendLine("  Method: " + ms[m].ReturnType.Name + " " + ms[m].Name + "(" + pStr + ")");
                    }
                }

                string outPath = Path.Combine(Paths.BepInExRootPath, "HIF_Exact_Classes.txt");
                File.WriteAllText(outPath, sb.ToString(), Encoding.UTF8);
                _status = "Da xuat xong BepInEx\\HIF_Exact_Classes.txt! Hay gui file nay cho minh de fix chuan 100%!";
            }
            catch (Exception ex)
            {
                _status = "Loi F6: " + ex.Message;
            }
        }

        private void ForceUnlockAllCurrentUIButtons()
        {
            int count = 0;
            Button[] btns = UnityEngine.Object.FindObjectsOfType<Button>();
            for (int i = 0; i < btns.Length; i++)
            {
                if (btns[i] != null && !btns[i].interactable)
                {
                    btns[i].interactable = true;
                    count++;
                }
            }

            Image[] imgs = UnityEngine.Object.FindObjectsOfType<Image>();
            for (int i = 0; i < imgs.Length; i++)
            {
                if (imgs[i] == null || !imgs[i].gameObject.activeInHierarchy) continue;
                string gn = imgs[i].gameObject.name.ToLower();
                string sn = (imgs[i].sprite != null && imgs[i].sprite.name != null) ? imgs[i].sprite.name.ToLower() : "";

                if (gn == "lock" || gn == "locked" || gn == "lockicon" || gn == "lock_icon" || gn == "img_lock" ||
                    gn == "lockmask" || gn == "mask_lock" || gn.Contains("lockimage") || gn.Contains("weijiesuo") ||
                    sn.Contains("lock") || sn.Contains("suo"))
                {
                    imgs[i].gameObject.SetActive(false);
                    count++;
                }
            }
            if (count > 0) _status = "Da go khoa " + count + " nut UI!";
        }

        private void GenerateAndWrite100PercentSaveFileSafe(int slotIndex)
        {
            try
            {
                ScanEverythingInGame();
                BackupExistingSaveFiles();
                UnlockGalleryCleanly();
                InstantCompleteAllActiveQuests();
                ExecuteMultiChannelMoneyAndStats(999999);
                MaxAllGirlAffectionAndShame();
                MultiplyAllExistingBagItems(999);

                int saveCalls = 0;
                for (int i = 0; i < _saveMethods.Count; i++)
                {
                    MethodCallEntry sm = _saveMethods[i];
                    string sigLow = sm.Signature.ToLower();
                    if (sigLow.Contains("weather") || sigLow.Contains("audio") || sigLow.Contains("volume")) continue;
                    if (InvokeSaveMethod(sm, slotIndex)) saveCalls++;
                }

                PlayerPrefs.Save();

                string dataDir = Application.dataPath;
                string rootDir = Path.GetDirectoryName(dataDir);
                string fullSaveExportDir = Path.Combine(rootDir, "FullSave_100Percent_Generated");
                if (!Directory.Exists(fullSaveExportDir)) Directory.CreateDirectory(fullSaveExportDir);

                CopyDatAndJsonSaves(dataDir, fullSaveExportDir);
                CopyDatAndJsonSaves(Application.persistentDataPath, fullSaveExportDir);

                _status = string.Format("HOAN TAT 100%! Da cap nhat RAM + goi {0} ham Save! Hay bam 'Luu Game' trong game de luu de!", saveCalls);
            }
            catch (Exception ex)
            {
                _status = "Loi tao Full Save: " + ex.Message;
            }
        }

        // ==================== TAB 1: QUEST TRACKER & TELE ====================
        private void DrawQuestTrackerAndTeleTab()
        {
            GUILayout.BeginVertical(_boxStyle);
            GUILayout.Label("Theo Doi Nhiem Vu Hien Tai & Dich Chuyen Toi Do Dang Thieu", _headerStyle);

            GUILayout.BeginHorizontal();
            if (GUILayout.Button("1. QUET NHIEM VU HIEN TAI & VAT PHAM TREN MAP", GUILayout.Height(32f)))
            {
                ScanEverythingInGame();
                ScanEspTargets();
            }
            if (GUILayout.Button("★ HOAN THANH NGAY NHIEM VU ★", GUILayout.Height(32f)))
            {
                InstantCompleteAllActiveQuests();
            }
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            if (GUILayout.Button("HUT TAT CA VAT PHAM TREN MAP VE DUOI CHAN MINH (AUTO LOOT)")) PullAllItemsOnMapToPlayer();
            bool newNoClip = GUILayout.Toggle(_noClipWalkThroughWalls, "Di Xuyen Tuong (NoClip)");
            if (newNoClip != _noClipWalkThroughWalls)
            {
                _noClipWalkThroughWalls = newNoClip;
                TogglePlayerNoClip(_noClipWalkThroughWalls);
            }
            GUILayout.EndHorizontal();

            _clickTeleportMode = GUILayout.Toggle(_clickTeleportMode, "Bat Click Chuot Phai De Dich Chuyen (Hoac giu phim Alt + Click Chuot Trai)");
            GUILayout.EndVertical();

            GUILayout.Space(6f);

            GUILayout.BeginVertical(_boxStyle);
            GUILayout.Label("A. Nhiem Vu Dang Lam & Dieu Kien Con Thieu (" + _activeQuests.Count + "):", _headerStyle);

            if (_activeQuests.Count == 0)
            {
                GUILayout.Label("Hay vao trong game (Load Save) roi bam nut '1. QUET NHIEM VU HIEN TAI' phia tren!");
            }
            else
            {
                for (int i = 0; i < _activeQuests.Count; i++)
                {
                    ActiveQuestEntry q = _activeQuests[i];
                    GUILayout.BeginVertical(_boxStyle);
                    GUILayout.Label("★ Nhiem vu: " + q.Title, _subHeaderStyle);
                    if (!string.IsNullOrEmpty(q.Description)) GUILayout.Label("   Chi tiet / Con thieu: " + q.Description);
                    if (!string.IsNullOrEmpty(q.MissingSummary)) GUILayout.Label("   Tien do RAM: " + q.MissingSummary);

                    GUILayout.BeginHorizontal();
                    if (q.ProgressSlots.Count > 0)
                    {
                        if (GUILayout.Button("Lap Day Tien Do (99/99)", GUILayout.Width(160f)))
                        {
                            for (int s = 0; s < q.ProgressSlots.Count; s++) q.ProgressSlots[s].Write(99);
                            _status = "Da lap day tien do cho nhiem vu: " + q.Title;
                        }
                    }

                    if (q.MatchingMapObjects.Count > 0)
                    {
                        for (int m = 0; m < Math.Min(q.MatchingMapObjects.Count, 3); m++)
                        {
                            Transform targetT = q.MatchingMapObjects[m];
                            if (targetT == null) continue;
                            if (GUILayout.Button("Tele Toi Nhat #" + (m + 1) + " (" + targetT.name + ")", GUILayout.Width(185f)))
                                TeleportPlayerTo(targetT.position);
                            if (GUILayout.Button("Keo Ve Minh", GUILayout.Width(95f)))
                                PullTransformToPlayer(targetT);
                        }
                    }
                    else
                    {
                        if (GUILayout.Button("Bat ESP Tim Tren Map", GUILayout.Width(160f))) { _enableEsp = true; ScanEspTargets(); }
                    }
                    GUILayout.EndHorizontal();
                    GUILayout.EndVertical();
                }
            }
            GUILayout.EndVertical();

            GUILayout.Space(6f);

            GUILayout.BeginVertical(_boxStyle);
            GUILayout.Label("B. Tat Ca Vat Pham / NPC Tren Map Hien Tai (" + _espNodes.Count + "):", _headerStyle);
            if (_espNodes.Count == 0)
            {
                if (GUILayout.Button("Quet Toan Bo Vat Pham & NPC Tren Map Ngay")) ScanEspTargets();
            }
            else
            {
                Transform pt = FindPlayerTransform();
                for (int i = 0; i < Math.Min(_espNodes.Count, 30); i++)
                {
                    EspNode en = _espNodes[i];
                    if (en.Trans == null) continue;
                    float dist = pt != null ? Vector2.Distance(pt.position, en.Trans.position) : 0f;

                    GUILayout.BeginHorizontal();
                    GUILayout.Label(string.Format("{0} (Cach {1:F1}m)", en.VietName, dist), GUILayout.Width(370f));
                    if (GUILayout.Button("Tele Toi Day", GUILayout.Width(110f))) TeleportPlayerTo(en.Trans.position);
                    if (GUILayout.Button("Hut Ve Chan", GUILayout.Width(100f))) PullTransformToPlayer(en.Trans);
                    GUILayout.EndHorizontal();
                }
            }
            GUILayout.EndVertical();
        }

        // ==================== TAB 2: MONEY HACK ====================
        private void DrawMoneyHackTab()
        {
            GUILayout.BeginVertical(_boxStyle);
            GUILayout.Label("Cach 1: Hook Mua Sam Mien Phi & Khong Bao Gio Tru Tien", _headerStyle);
            if (GUILayout.Button("★ BAT CHE DO MUA DO MIEN PHI + TANG TIEN KHI MUA ★", GUILayout.Height(36f)))
            {
                ApplyFreeShoppingAndNoSpendHooks();
            }
            GUILayout.EndVertical();

            GUILayout.Space(6f);

            GUILayout.BeginVertical(_boxStyle);
            GUILayout.Label("Cach 2: Do Chinh Xac Bien Tien / The Luc Trong RAM (Chuan 100%)", _headerStyle);
            GUILayout.BeginHorizontal();
            GUILayout.Label("So tien dang co:", GUILayout.Width(110f));
            _exactSearchStr = GUILayout.TextField(_exactSearchStr, GUILayout.Width(95f));
            if (GUILayout.Button("1. Quet Lan Dau (First Scan)", GUILayout.Width(175f))) RunExactValueScan(_exactSearchStr, false);
            if (GUILayout.Button("2. Loc Khi Tien Doi (Next Scan)", GUILayout.Width(190f))) RunExactValueScan(_exactSearchStr, true);
            GUILayout.EndHorizontal();

            GUILayout.Space(4f);
            GUILayout.BeginHorizontal();
            GUILayout.Label("So tien muon dat:", GUILayout.Width(110f));
            _targetMoneyStr = GUILayout.TextField(_targetMoneyStr, GUILayout.Width(95f));
            if (GUILayout.Button("★ DOI TAT CA KET QUA (" + _matchedMoneySlots.Count + " bien) = " + _targetMoneyStr + " & KHOA ★"))
            {
                int targetVal = 999999;
                int.TryParse(_targetMoneyStr, out targetVal);
                for (int i = 0; i < _matchedMoneySlots.Count; i++)
                {
                    _matchedMoneySlots[i].Write(targetVal);
                    _matchedMoneySlots[i].IsFrozen = true;
                    _matchedMoneySlots[i].FrozenVal = targetVal;
                }
                _status = "Da doi & KHOA " + _matchedMoneySlots.Count + " bien = " + targetVal + "!";
            }
            GUILayout.EndHorizontal();
            GUILayout.EndVertical();

            GUILayout.Space(6f);

            GUILayout.BeginVertical(_boxStyle);
            GUILayout.Label("Cach 3: Bom Tien Tu Dong Qua Moi Kenh", _headerStyle);
            if (GUILayout.Button("★ BOM 999,999 TIEN + THE LUC + HAO CAM ★", GUILayout.Height(34f)))
            {
                int tv = 999999;
                int.TryParse(_targetMoneyStr, out tv);
                if (tv <= 0) tv = 999999;
                ExecuteMultiChannelMoneyAndStats(tv);
            }
            GUILayout.EndVertical();

            if (_matchedMoneySlots.Count > 0)
            {
                GUILayout.Space(6f);
                GUILayout.BeginVertical(_boxStyle);
                GUILayout.Label("Bien Khop Con So (" + _matchedMoneySlots.Count + "):", _headerStyle);
                for (int i = 0; i < Math.Min(_matchedMoneySlots.Count, 35); i++)
                {
                    MemorySlot ms = _matchedMoneySlots[i];
                    object cur = ms.Read();
                    GUILayout.BeginHorizontal();
                    GUILayout.Label(ms.Path + " = " + (cur != null ? cur.ToString() : "null"), GUILayout.Width(380f));
                    if (GUILayout.Button("Set 999999", GUILayout.Width(95f))) { ms.Write(999999); ms.IsFrozen = true; ms.FrozenVal = 999999; }
                    bool fz = GUILayout.Toggle(ms.IsFrozen, "Khoa", GUILayout.Width(65f));
                    if (fz != ms.IsFrozen) { ms.IsFrozen = fz; if (ms.IsFrozen) ms.FrozenVal = ms.Read(); }
                    GUILayout.EndHorizontal();
                }
                GUILayout.EndVertical();
            }
        }

        // ==================== TAB 3: GIVE ITEMS ====================
        private void DrawGiveItemsTab()
        {
            GUILayout.BeginVertical(_boxStyle);
            GUILayout.Label("Give Vat Pham Tieng Viet & Nhan Ban Tui Do (x999)", _headerStyle);

            GUILayout.BeginHorizontal();
            GUILayout.Label("So luong:", GUILayout.Width(70f));
            _giveAmountStr = GUILayout.TextField(_giveAmountStr, GUILayout.Width(75f));
            int.TryParse(_giveAmountStr, out _giveAmount);
            if (_giveAmount <= 0) _giveAmount = 99;

            if (GUILayout.Button("x99", GUILayout.Width(50f))) { _giveAmount = 99; _giveAmountStr = "99"; }
            if (GUILayout.Button("x999", GUILayout.Width(55f))) { _giveAmount = 999; _giveAmountStr = "999"; }
            if (GUILayout.Button("★ TANG TAT CA DO DANG CO TRONG TUI LEN " + _giveAmount + " ★")) MultiplyAllExistingBagItems(_giveAmount);
            GUILayout.EndHorizontal();
            GUILayout.EndVertical();

            GUILayout.Space(6f);

            GUILayout.BeginVertical(_boxStyle);
            GUILayout.Label("Chon Nhom Vat Pham Bang Tieng Viet De Nhan Ngay:", _headerStyle);
            for (int i = 0; i < _vietCategories.Count; i++)
            {
                VietItemCat cat = _vietCategories[i];
                GUILayout.BeginHorizontal();
                GUILayout.Label("• " + cat.VietTitle, GUILayout.Width(430f));
                if (GUILayout.Button("Nhan +" + _giveAmount, GUILayout.Width(130f))) GiveVietnameseCategory(cat, _giveAmount);
                GUILayout.EndHorizontal();
            }
            GUILayout.EndVertical();

            GUILayout.Space(6f);

            GUILayout.BeginVertical(_boxStyle);
            GUILayout.Label("O Tui Do Thuc Te Tim Thay Trong RAM (" + _bagSlots.Count + "):", _headerStyle);
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("Quet Tui Do Thuc Te", GUILayout.Width(160f))) ScanEverythingInGame();
            GUILayout.Label("Loc:", GUILayout.Width(35f));
            _bagSearchFilter = GUILayout.TextField(_bagSearchFilter);
            GUILayout.EndHorizontal();

            string bf = string.IsNullOrEmpty(_bagSearchFilter) ? "" : _bagSearchFilter.ToLower();
            int shown = 0;
            for (int i = 0; i < _bagSlots.Count; i++)
            {
                BagSlotEntry b = _bagSlots[i];
                if (!string.IsNullOrEmpty(bf) && !b.VietName.ToLower().Contains(bf) && !b.RawName.ToLower().Contains(bf)) continue;
                if (shown >= 35) break;
                shown++;

                object cur = b.CountSlot.Read();
                GUILayout.BeginHorizontal();
                GUILayout.Label(string.Format("[ID:{0}] {1} (SL: {2})", b.ItemId, b.VietName, cur), GUILayout.Width(430f));
                if (GUILayout.Button("Set = " + _giveAmount, GUILayout.Width(130f)))
                {
                    b.CountSlot.Write(_giveAmount);
                    _status = "Da dat " + b.VietName + " = " + _giveAmount;
                }
                GUILayout.EndHorizontal();
            }
            GUILayout.EndVertical();
        }

        // ==================== TAB 4: SCENE, ESP & 4K ====================
        private void DrawSceneAndGraphicsTab()
        {
            GUILayout.BeginVertical(_boxStyle);
            GUILayout.Label("1. Max Hao Cam Nhan Vat Nu & The Luc", _headerStyle);
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("Max 999 Hao Cam & Shame Tat Ca Co Gai")) MaxAllGirlAffectionAndShame();
            if (GUILayout.Button("Hoi Day 999 The Luc (Stamina)")) ExecuteMultiChannelMoneyAndStats(999999);
            GUILayout.EndHorizontal();
            GUILayout.EndVertical();

            GUILayout.Space(6f);

            GUILayout.BeginVertical(_boxStyle);
            GUILayout.Label("2. ESP Dinh Vi Vat Pham Nhiem Vu Tren Man Hinh [Phim tat: F7]", _headerStyle);
            bool ne = GUILayout.Toggle(_enableEsp, "BAT ESP Ve Khung + Duong Chi Dan Toi Vat Pham (F7)");
            if (ne != _enableEsp) { _enableEsp = ne; if (_enableEsp) ScanEspTargets(); }
            _espLines = GUILayout.Toggle(_espLines, "Ve duong ke tu giua man hinh toi vat pham");

            GUILayout.BeginHorizontal();
            GUILayout.Label("Loc ten:", GUILayout.Width(65f));
            _espFilter = GUILayout.TextField(_espFilter);
            if (GUILayout.Button("Quet Map", GUILayout.Width(100f))) ScanEspTargets();
            if (GUILayout.Button("Hut Tat Ca Ve Minh", GUILayout.Width(150f))) PullAllItemsOnMapToPlayer();
            GUILayout.EndHorizontal();
            GUILayout.EndVertical();

            GUILayout.Space(6f);

            GUILayout.BeginVertical(_boxStyle);
            GUILayout.Label("3. Do Hoa 4K Ultra & Toc Do Game", _headerStyle);
            bool n4 = GUILayout.Toggle(_enable4K, "Khoa Do Phan Giai 4K (3840x2160) + MSAA 8x + MipBias -1.0");
            if (n4 != _enable4K) { _enable4K = n4; if (_enable4K) Apply4KGraphics(); }

            GUILayout.Space(4f);
            _lockSpeed = GUILayout.Toggle(_lockSpeed, "Khoa Toc Do Game (TimeScale)");
            GUILayout.Label(string.Format("Toc do: {0:F2}x", _timeScale));
            _timeScale = GUILayout.HorizontalSlider(_timeScale, 0f, 10f);

            GUILayout.BeginHorizontal();
            if (GUILayout.Button("1x")) { _timeScale = 1f; Time.timeScale = 1f; }
            if (GUILayout.Button("2x")) { _timeScale = 2f; _lockSpeed = true; }
            if (GUILayout.Button("5x")) { _timeScale = 5f; _lockSpeed = true; }
            if (GUILayout.Button("An/Hien UI (F10)")) ToggleUI();
            GUILayout.EndHorizontal();
            GUILayout.EndVertical();
        }

        // ==================== CORE SCANNER & HELPERS ====================
        private void ScanEverythingInGame()
        {
            _allNumericSlots.Clear();
            _bagSlots.Clear();
            _activeQuests.Clear();
            _gameMethods.Clear();
            _saveMethods.Clear();
            _galleryUnlockMethods.Clear();

            HashSet<object> visited = new HashSet<object>();

            MonoBehaviour[] monos = UnityEngine.Object.FindObjectsOfType<MonoBehaviour>();
            for (int i = 0; i < monos.Length; i++)
            {
                MonoBehaviour mb = monos[i];
                if (mb == null || mb == this) continue;
                Type t = mb.GetType();
                if (t == typeof(HIFModMenuPlugin)) continue;
                string ns = t.Namespace ?? "";
                if (ns.StartsWith("UnityEngine") || ns.StartsWith("TMPro") || ns.StartsWith("BepInEx") || ns.StartsWith("System") || ns.StartsWith("HIFModMenu"))
                    continue;

                CollectCallableMethods(mb, t);
                TraverseObjectGraph(mb, t.Name, visited, 0);
            }

            Assembly gameAsm = FindAssemblyByName("Assembly-CSharp");
            if (gameAsm != null)
            {
                try
                {
                    Type[] types = gameAsm.GetTypes();
                    for (int i = 0; i < types.Length; i++)
                    {
                        Type t = types[i];
                        if (t.IsInterface || t.IsEnum || t == typeof(HIFModMenuPlugin)) continue;

                        CollectCallableMethods(null, t);

                        FieldInfo[] sfs = t.GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static);
                        for (int f = 0; f < sfs.Length; f++)
                        {
                            FieldInfo sf = sfs[f];
                            if (sf.IsLiteral) continue;
                            object val = null;
                            try { val = sf.GetValue(null); } catch { }
                            if (val != null)
                            {
                                if (IsNumericOrBool(sf.FieldType)) AddSlot(null, t.Name + "." + sf.Name, sf, null);
                                else TraverseObjectGraph(val, t.Name + "." + sf.Name, visited, 0);
                            }
                        }
                    }
                }
                catch { }
            }

            ScanActiveQuestTextsAndLinkMap();
        }

        private Assembly FindAssemblyByName(string shortName)
        {
            Assembly[] asms = AppDomain.CurrentDomain.GetAssemblies();
            for (int i = 0; i < asms.Length; i++)
            {
                if (asms[i].GetName().Name == shortName) return asms[i];
            }
            return null;
        }

        private void TraverseObjectGraph(object obj, string path, HashSet<object> visited, int depth)
        {
            if (obj == null || depth > 3 || _allNumericSlots.Count > 15000) return;
            Type t = obj.GetType();
            if (t.IsPrimitive || t == typeof(string) || t.IsEnum || t == typeof(HIFModMenuPlugin)) return;

            if (!t.IsValueType)
            {
                if (visited.Contains(obj)) return;
                visited.Add(obj);
            }

            TryInspectAsQuestObject(obj, path);

            if (obj is IDictionary)
            {
                IDictionary dict = (IDictionary)obj;
                int c = 0;
                foreach (DictionaryEntry de in dict)
                {
                    if (c++ > 100) break;
                    if (de.Key == null || de.Value == null) continue;
                    Type vt = de.Value.GetType();
                    if (IsNumericOrBool(vt))
                    {
                        MemorySlot ms = new MemorySlot();
                        ms.Dict = dict;
                        ms.DictKey = de.Key;
                        ms.Path = path + "[" + de.Key + "]";
                        _allNumericSlots.Add(ms);

                        int idKey;
                        if (int.TryParse(de.Key.ToString(), out idKey))
                        {
                            BagSlotEntry bse = new BagSlotEntry();
                            bse.ItemId = idKey;
                            bse.RawName = ms.Path;
                            bse.VietName = TranslateToViet(ms.Path, idKey);
                            bse.CountSlot = ms;
                            _bagSlots.Add(bse);
                        }
                    }
                    else
                    {
                        TryInspectAsBagItemObject(de.Value, path + "[" + de.Key + "]");
                        TraverseObjectGraph(de.Value, path + "[" + de.Key + "]", visited, depth + 1);
                    }
                }
                return;
            }

            if (obj is IList)
            {
                IList list = (IList)obj;
                int limit = Math.Min(list.Count, 100);
                for (int i = 0; i < limit; i++)
                {
                    object elem = list[i];
                    if (elem == null) continue;
                    Type et = elem.GetType();
                    if (IsNumericOrBool(et))
                    {
                        MemorySlot ms = new MemorySlot();
                        ms.List = list;
                        ms.ListIndex = i;
                        ms.Path = path + "[" + i + "]";
                        _allNumericSlots.Add(ms);
                    }
                    else
                    {
                        TryInspectAsBagItemObject(elem, path + "[" + i + "]");
                        TraverseObjectGraph(elem, path + "[" + i + "]", visited, depth + 1);
                    }
                }
                return;
            }

            BindingFlags flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

            FieldInfo[] fields = t.GetFields(flags);
            for (int i = 0; i < fields.Length; i++)
            {
                FieldInfo f = fields[i];
                Type ft = f.FieldType;
                string cleanName = f.Name.Replace("<", "").Replace(">k__BackingField", "");
                if (IsNumericOrBool(ft)) AddSlot(obj, path + "." + cleanName, f, null);
                else if (ft != typeof(string) && !ft.FullName.StartsWith("UnityEngine") && !ft.FullName.StartsWith("System.Action"))
                {
                    object child = null;
                    try { child = f.GetValue(obj); } catch { }
                    if (child != null) TraverseObjectGraph(child, path + "." + cleanName, visited, depth + 1);
                }
            }

            PropertyInfo[] props = t.GetProperties(flags);
            for (int i = 0; i < props.Length; i++)
            {
                PropertyInfo p = props[i];
                if (!p.CanRead || !p.CanWrite || p.GetIndexParameters().Length > 0) continue;
                if (IsNumericOrBool(p.PropertyType)) AddSlot(obj, path + "." + p.Name, null, p);
            }
        }

        private void AddSlot(object owner, string path, FieldInfo f, PropertyInfo p)
        {
            MemorySlot ms = new MemorySlot();
            ms.Owner = owner;
            ms.Path = path;
            ms.Field = f;
            ms.Prop = p;
            _allNumericSlots.Add(ms);
        }

        private void TryInspectAsBagItemObject(object elem, string path)
        {
            if (elem == null) return;
            Type t = elem.GetType();
            BindingFlags flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

            FieldInfo countF = null;
            FieldInfo idF = null;
            FieldInfo nameF = null;

            FieldInfo[] fs = t.GetFields(flags);
            for (int i = 0; i < fs.Length; i++)
            {
                string fn = fs[i].Name.ToLower();
                if (IsNumericType(fs[i].FieldType))
                {
                    if (fn.Contains("count") || fn.Contains("num") || fn.Contains("amount") || fn.Contains("stack") || fn.Contains("qty") || fn.Contains("shuliang") || fn.Contains("val"))
                    {
                        if (countF == null) countF = fs[i];
                    }
                    else if (fn.Contains("id") || fn.Contains("code") || fn.Contains("index"))
                    {
                        if (idF == null) idF = fs[i];
                    }
                }
                else if (fs[i].FieldType == typeof(string))
                {
                    if (fn.Contains("name") || fn.Contains("title") || fn.Contains("key") || fn.Contains("id"))
                    {
                        if (nameF == null) nameF = fs[i];
                    }
                }
            }

            if (countF == null) return;

            int idVal = 0;
            if (idF != null) { try { idVal = Convert.ToInt32(idF.GetValue(elem)); } catch { } }

            string rawName = t.Name;
            if (nameF != null)
            {
                try
                {
                    object nv = nameF.GetValue(elem);
                    if (nv != null && !string.IsNullOrEmpty(nv.ToString())) rawName = nv.ToString();
                }
                catch { }
            }

            MemorySlot slot = new MemorySlot();
            slot.Owner = elem;
            slot.Field = countF;
            slot.Path = path + "." + countF.Name;

            BagSlotEntry bse = new BagSlotEntry();
            bse.ItemId = idVal;
            bse.RawName = rawName;
            bse.VietName = TranslateToViet(rawName + " " + path, idVal);
            bse.CountSlot = slot;
            bse.ItemObj = elem;
            _bagSlots.Add(bse);
        }

        private void TryInspectAsQuestObject(object obj, string path)
        {
            Type t = obj.GetType();
            string tn = t.Name.ToLower();
            if (!tn.Contains("quest") && !tn.Contains("task") && !tn.Contains("mission") && !tn.Contains("renwu") && !tn.Contains("objective"))
                return;

            BindingFlags flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            FieldInfo[] fs = t.GetFields(flags);

            string title = "";
            string desc = "";
            StringBuilder numSummary = new StringBuilder();
            List<MemorySlot> progSlots = new List<MemorySlot>();

            for (int i = 0; i < fs.Length; i++)
            {
                FieldInfo f = fs[i];
                string fn = f.Name.Replace("<", "").Replace(">k__BackingField", "");
                string fnLow = fn.ToLower();

                if (f.FieldType == typeof(string))
                {
                    string sv = null;
                    try { sv = f.GetValue(obj) as string; } catch { }
                    if (!string.IsNullOrEmpty(sv))
                    {
                        if (fnLow.Contains("name") || fnLow.Contains("title")) title = sv;
                        else if (fnLow.Contains("desc") || fnLow.Contains("info") || fnLow.Contains("content") || fnLow.Contains("tip") || fnLow.Contains("target"))
                            desc += sv + " | ";
                    }
                }
                else if (IsNumericType(f.FieldType))
                {
                    object nv = null;
                    try { nv = f.GetValue(obj); } catch { }
                    if (nv != null)
                    {
                        numSummary.Append(fn).Append("=").Append(nv).Append(" ");
                        if (fnLow.Contains("cur") || fnLow.Contains("prog") || fnLow.Contains("count") || fnLow.Contains("num") || fnLow.Contains("step") || fnLow.Contains("state") || fnLow.Contains("status"))
                        {
                            MemorySlot ms = new MemorySlot();
                            ms.Owner = obj;
                            ms.Field = f;
                            ms.Path = path + "." + fn;
                            progSlots.Add(ms);
                        }
                    }
                }
            }

            if (string.IsNullOrEmpty(title) && string.IsNullOrEmpty(desc) && progSlots.Count == 0) return;

            ActiveQuestEntry aqe = new ActiveQuestEntry();
            aqe.Title = !string.IsNullOrEmpty(title) ? title : (t.Name + " (" + path + ")");
            aqe.Description = desc;
            aqe.MissingSummary = numSummary.ToString();
            aqe.SourceObj = obj;
            aqe.ProgressSlots = progSlots;
            _activeQuests.Add(aqe);
        }

        private void ScanActiveQuestTextsAndLinkMap()
        {
            ScanEspTargets();

            Text[] uiTexts = UnityEngine.Object.FindObjectsOfType<Text>();
            for (int i = 0; i < uiTexts.Length; i++)
            {
                if (uiTexts[i] == null || !uiTexts[i].gameObject.activeInHierarchy) continue;
                string txt = uiTexts[i].text;
                if (string.IsNullOrEmpty(txt) || txt.Length < 3) continue;

                string goName = uiTexts[i].gameObject.name.ToLower();
                string parentName = uiTexts[i].transform.parent != null ? uiTexts[i].transform.parent.name.ToLower() : "";

                bool isQuestUi = goName.Contains("quest") || goName.Contains("task") || goName.Contains("mission") || goName.Contains("renwu") ||
                                 parentName.Contains("quest") || parentName.Contains("task") || parentName.Contains("mission") ||
                                 txt.Contains("/");

                if (isQuestUi)
                {
                    ActiveQuestEntry uq = new ActiveQuestEntry();
                    uq.Title = "[UI Nhiem Vu] " + txt.Replace("\n", " ");
                    uq.Description = "Obj UI: " + uiTexts[i].gameObject.name;
                    _activeQuests.Add(uq);
                }
            }

            for (int i = 0; i < _activeQuests.Count; i++)
            {
                ActiveQuestEntry q = _activeQuests[i];
                string combined = (q.Title + " " + q.Description).ToLower();

                for (int e = 0; e < _espNodes.Count; e++)
                {
                    EspNode en = _espNodes[e];
                    if (en.Trans == null) continue;
                    string enLow = (en.Trans.name + " " + en.VietName).ToLower();

                    if (en.IsQuestTarget || WordsOverlap(combined, enLow))
                    {
                        if (!q.MatchingMapObjects.Contains(en.Trans))
                            q.MatchingMapObjects.Add(en.Trans);
                    }
                }
            }
        }

        private bool WordsOverlap(string a, string b)
        {
            string[] keys = new string[] { "wood", "stone", "iron", "herb", "flower", "shell", "fish", "cat", "recipe", "tofu", "chest", "fragment", "key", "letter", "book", "go", "da", "sat", "meo", "cong thuc" };
            for (int i = 0; i < keys.Length; i++)
            {
                if (a.Contains(keys[i]) && b.Contains(keys[i])) return true;
            }
            return false;
        }

        private void CollectCallableMethods(object target, Type t)
        {
            if (t == typeof(HIFModMenuPlugin) || (t.Namespace != null && t.Namespace.StartsWith("HIFModMenu"))) return;

            BindingFlags flags = BindingFlags.Public | BindingFlags.NonPublic | (target != null ? BindingFlags.Instance : BindingFlags.Static) | BindingFlags.DeclaredOnly;
            MethodInfo[] ms = t.GetMethods(flags);
            for (int i = 0; i < ms.Length; i++)
            {
                MethodInfo m = ms[i];
                string mn = m.Name.ToLower();
                string tn = t.Name.ToLower();
                ParameterInfo[] ps = m.GetParameters();
                if (ps.Length > 2) continue;

                if ((mn == "save" || mn == "savegame" || mn == "savedata" || mn == "writesave" || mn == "autosave") && !mn.Contains("load") && ps.Length <= 1)
                {
                    MethodCallEntry sm = new MethodCallEntry();
                    sm.Target = target;
                    sm.Method = m;
                    sm.Signature = t.Name + "." + m.Name + "(" + ps.Length + " args)";
                    _saveMethods.Add(sm);
                }

                if ((mn.Contains("unlockall") || mn.Contains("opengallery") || mn.Contains("unlockcg") || mn.Contains("unlockmemory")) && ps.Length <= 1)
                {
                    MethodCallEntry gm = new MethodCallEntry();
                    gm.Target = target;
                    gm.Method = m;
                    gm.Signature = t.Name + "." + m.Name + "(" + ps.Length + " args)";
                    _galleryUnlockMethods.Add(gm);
                }

                if (mn.Contains("add") || mn.Contains("give") || mn.Contains("gain") || mn.Contains("set"))
                {
                    if (mn.Contains("gold") || mn.Contains("money") || mn.Contains("coin") || mn.Contains("jinbi") || mn.Contains("item") || mn.Contains("prop") || mn.Contains("bag"))
                    {
                        MethodCallEntry mce = new MethodCallEntry();
                        mce.Target = target;
                        mce.Method = m;
                        mce.Signature = t.Name + "." + m.Name + "(" + ps.Length + " args)";
                        _gameMethods.Add(mce);
                    }
                }
            }
        }

        private void ApplyFreeShoppingAndNoSpendHooks()
        {
            if (_freeShoppingHook) return;
            int patched = 0;
            try
            {
                Harmony harmony = new Harmony("com.thanhsama.hifmodmenu.freeshop71");
                MethodInfo postfixTrue = typeof(HIFModMenuPlugin).GetMethod("PostfixAlwaysTrue", BindingFlags.Static | BindingFlags.NonPublic);
                MethodInfo prefixAbs = typeof(HIFModMenuPlugin).GetMethod("PrefixMakePositive", BindingFlags.Static | BindingFlags.NonPublic);

                Assembly gameAsm = FindAssemblyByName("Assembly-CSharp");
                if (gameAsm != null)
                {
                    Type[] types = null;
                    try { types = gameAsm.GetTypes(); } catch { }
                    if (types != null)
                    {
                        for (int t = 0; t < types.Length; t++)
                        {
                            Type type = types[t];
                            if (type == typeof(HIFModMenuPlugin) || type.IsInterface || type.IsEnum || type.IsGenericTypeDefinition) continue;

                            MethodInfo[] ms = type.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly);
                            for (int m = 0; m < ms.Length; m++)
                            {
                                MethodInfo mi = ms[m];
                                if (mi.IsAbstract || mi.ContainsGenericParameters) continue;

                                string mn = mi.Name.ToLower();
                                ParameterInfo[] ps = mi.GetParameters();

                                if (mi.ReturnType == typeof(bool) && (mn.Contains("canbuy") || mn.Contains("canafford") || mn.Contains("enough") || mn.Contains("checkmoney") || mn.Contains("checkgold") || mn.Contains("checkcoin") || mn.Contains("checkcost") || mn.Contains("hasitem")))
                                {
                                    try { harmony.Patch(mi, null, new HarmonyMethod(postfixTrue)); patched++; } catch { }
                                }

                                if (ps.Length == 1 && ps[0].ParameterType == typeof(int) && (mn.Contains("gold") || mn.Contains("money") || mn.Contains("coin") || mn.Contains("jinbi") || mn.Contains("cash")))
                                {
                                    if (mn.Contains("add") || mn.Contains("change") || mn.Contains("modify"))
                                    {
                                        try { harmony.Patch(mi, new HarmonyMethod(prefixAbs), null); patched++; } catch { }
                                    }
                                }
                            }
                        }
                    }
                }
                _freeShoppingHook = true;
                _status = "Da bat Mua Do Mien Phi & Khong Tru Tien (" + patched + " ham)!";
            }
            catch (Exception ex) { _status = "Loi FreeShop Hook: " + ex.Message; }
        }

        private static void PostfixAlwaysTrue(ref bool __result) { __result = true; }
        private static void PrefixMakePositive(ref int __0) { if (__0 < 0) __0 = -__0; if (__0 == 0) __0 = 9999; }

        private bool InvokeSaveMethod(MethodCallEntry sm, int slotIndex)
        {
            try
            {
                ParameterInfo[] ps = sm.Method.GetParameters();
                if (ps.Length == 0) { sm.Method.Invoke(sm.Target, null); return true; }
                if (ps.Length == 1 && ps[0].ParameterType == typeof(int)) { sm.Method.Invoke(sm.Target, new object[] { slotIndex }); return true; }
                if (ps.Length == 1 && ps[0].ParameterType == typeof(bool)) { sm.Method.Invoke(sm.Target, new object[] { true }); return true; }
            }
            catch { }
            return false;
        }

        private void BackupExistingSaveFiles()
        {
            try
            {
                string dataDir = Application.dataPath;
                string rootDir = Path.GetDirectoryName(dataDir);
                string backupDir = Path.Combine(rootDir, "Backup_OriginSave");
                if (!Directory.Exists(backupDir)) Directory.CreateDirectory(backupDir);
                int count = CopyDatAndJsonSaves(dataDir, backupDir) + CopyDatAndJsonSaves(Application.persistentDataPath, backupDir);
                _status = "Da sao luu " + count + " file save goc vao Backup_OriginSave!";
            }
            catch (Exception ex) { _status = "Loi Backup: " + ex.Message; }
        }

        private void RestoreBackupSaveFiles()
        {
            try
            {
                string dataDir = Application.dataPath;
                string rootDir = Path.GetDirectoryName(dataDir);
                string backupDir = Path.Combine(rootDir, "Backup_OriginSave");
                if (!Directory.Exists(backupDir)) { _status = "Chua co Backup_OriginSave!"; return; }
                string[] files = Directory.GetFiles(backupDir);
                int restored = 0;
                for (int i = 0; i < files.Length; i++)
                {
                    string fn = Path.GetFileName(files[i]);
                    string dest1 = Path.Combine(dataDir, fn);
                    if (File.Exists(dest1)) { File.Copy(files[i], dest1, true); restored++; }
                    string dest2 = Path.Combine(Application.persistentDataPath, fn);
                    if (File.Exists(dest2)) { File.Copy(files[i], dest2, true); restored++; }
                }
                _status = "Da khoi phuc " + restored + " file save goc!";
            }
            catch (Exception ex) { _status = "Loi Restore: " + ex.Message; }
        }

        private int CopyDatAndJsonSaves(string srcDir, string dstDir)
        {
            if (string.IsNullOrEmpty(srcDir) || !Directory.Exists(srcDir)) return 0;
            int copied = 0;
            string[] patterns = new string[] { "*.dat", "*.sav", "*.save", "*.json", "*.es3" };
            for (int p = 0; p < patterns.Length; p++)
            {
                string[] files = Directory.GetFiles(srcDir, patterns[p], SearchOption.TopDirectoryOnly);
                for (int i = 0; i < files.Length; i++)
                {
                    string fn = Path.GetFileName(files[i]);
                    if (fn.ToLower().Contains("resource") || fn.ToLower().Contains("globalgamemanagers")) continue;
                    File.Copy(files[i], Path.Combine(dstDir, fn), true);
                    copied++;
                }
            }
            return copied;
        }

        private void MaxAllGirlAffectionAndShame()
        {
            if (_allNumericSlots.Count == 0) ScanEverythingInGame();
            int c = 0;
            string[] keys = new string[] { "affection", "favor", "love", "heart", "shame", "lust", "desire", "haogan", "xiuchi", "intimacy", "mood" };
            for (int i = 0; i < _allNumericSlots.Count; i++)
            {
                MemorySlot ms = _allNumericSlots[i];
                if (ms.SlotType == typeof(bool)) continue;
                string low = ms.Path.ToLower();
                for (int k = 0; k < keys.Length; k++)
                {
                    if (low.Contains(keys[k])) { ms.Write(999); c++; break; }
                }
            }
            _status = "Da Max 999 Hao Cam & Shame cho " + c + " chi so!";
        }

        private void TogglePlayerNoClip(bool enable)
        {
            Transform pt = FindPlayerTransform();
            if (pt == null) return;
            Component col2d = pt.GetComponent("Collider2D");
            if (col2d is Behaviour) ((Behaviour)col2d).enabled = !enable;
            _status = enable ? "Da bat Di Xuyen Tuong (NoClip)!" : "Da tat NoClip.";
        }

        private void RunExactValueScan(string valStr, bool nextScan)
        {
            double target;
            if (!double.TryParse(valStr, out target)) { _status = "Hay nhap 1 con so!"; return; }

            if (!nextScan)
            {
                ScanEverythingInGame();
                _matchedMoneySlots.Clear();
                for (int i = 0; i < _allNumericSlots.Count; i++)
                {
                    MemorySlot ms = _allNumericSlots[i];
                    if (ms.SlotType == typeof(bool)) continue;
                    object v = ms.Read();
                    if (v != null)
                    {
                        double d;
                        if (double.TryParse(v.ToString(), out d) && Math.Abs(d - target) < 0.01) _matchedMoneySlots.Add(ms);
                    }
                }
                _status = string.Format("Quet lan 1 (={0}): Tim thay {1} bien khop!", target, _matchedMoneySlots.Count);
            }
            else
            {
                List<MemorySlot> next = new List<MemorySlot>();
                for (int i = 0; i < _matchedMoneySlots.Count; i++)
                {
                    MemorySlot ms = _matchedMoneySlots[i];
                    object v = ms.Read();
                    if (v != null)
                    {
                        double d;
                        if (double.TryParse(v.ToString(), out d) && Math.Abs(d - target) < 0.01) next.Add(ms);
                    }
                }
                _matchedMoneySlots = next;
                _status = string.Format("Loc tiep (={0}): Con lai {1} bien!", target, _matchedMoneySlots.Count);
            }
        }

        private void ExecuteMultiChannelMoneyAndStats(int amount)
        {
            if (_allNumericSlots.Count == 0) ScanEverythingInGame();
            int count = 0;
            string[] keys = new string[] { "gold", "money", "coin", "cash", "jinbi", "qian", "currency", "wealth", "stamina", "energy", "tili", "affection", "favor", "haogan" };

            for (int i = 0; i < _allNumericSlots.Count; i++)
            {
                MemorySlot ms = _allNumericSlots[i];
                if (ms.SlotType == typeof(bool)) continue;
                string low = ms.Path.ToLower();
                for (int k = 0; k < keys.Length; k++)
                {
                    if (low.Contains(keys[k]))
                    {
                        int v = (keys[k] == "stamina" || keys[k] == "energy" || keys[k] == "tili") ? 999 : amount;
                        ms.Write(v);
                        ms.IsFrozen = true;
                        ms.FrozenVal = v;
                        count++;
                        break;
                    }
                }
            }
            _status = "Da bom Tien & Chi so qua " + count + " kenh!";
        }

        private void MultiplyAllExistingBagItems(int targetAmount)
        {
            if (_allNumericSlots.Count == 0) ScanEverythingInGame();
            int updated = 0;
            for (int i = 0; i < _bagSlots.Count; i++)
            {
                object cur = _bagSlots[i].CountSlot.Read();
                double d = 0;
                if (cur != null) double.TryParse(cur.ToString(), out d);
                if (d >= 1 && d < targetAmount) { _bagSlots[i].CountSlot.Write(targetAmount); updated++; }
            }
            _status = "Da nhan ban " + updated + " o vat pham len " + targetAmount + "!";
        }

        private void GiveVietnameseCategory(VietItemCat cat, int amount)
        {
            if (_allNumericSlots.Count == 0) ScanEverythingInGame();
            int hits = 0;
            for (int i = 0; i < _allNumericSlots.Count; i++)
            {
                MemorySlot ms = _allNumericSlots[i];
                if (ms.SlotType == typeof(bool)) continue;
                string low = ms.Path.ToLower();
                for (int k = 0; k < cat.Keywords.Length; k++)
                {
                    if (low.Contains(cat.Keywords[k])) { ms.Write(amount); hits++; break; }
                }
            }
            _status = string.Format("Da trao [{0}] (x{1}) qua {2} kenh!", cat.VietTitle, amount, hits);
        }

        private void InstantCompleteAllActiveQuests()
        {
            if (_allNumericSlots.Count == 0) ScanEverythingInGame();
            int count = 0;
            for (int i = 0; i < _activeQuests.Count; i++)
            {
                for (int s = 0; s < _activeQuests[i].ProgressSlots.Count; s++) { _activeQuests[i].ProgressSlots[s].Write(99); count++; }
            }
            _status = "Da lap day " + count + " chi so nhiem vu!";
        }

        private void ScanEspTargets()
        {
            _espNodes.Clear();
            GameObject[] allGos = UnityEngine.Object.FindObjectsOfType<GameObject>();
            string fl = string.IsNullOrEmpty(_espFilter) ? "" : _espFilter.ToLower();

            for (int i = 0; i < allGos.Length; i++)
            {
                GameObject go = allGos[i];
                if (go == null || !go.activeInHierarchy || go.GetComponent<RectTransform>() != null) continue;
                string n = go.name;
                string low = n.ToLower();
                if (low.Contains("camera") || low.Contains("light") || low.Contains("tilemap") || low.Contains("grid") ||
                    low.Contains("ground") || low.Contains("floor") || low.Contains("wall") || low.Contains("audio") ||
                    low.Contains("bgm") || low.Contains("manager") || low.Contains("canvas") || low.Contains("shadow") ||
                    low.Contains("particle") || low == "player") continue;

                MonoBehaviour[] comps = go.GetComponents<MonoBehaviour>();
                string compNames = "";
                bool hasCustomScript = false;
                for (int c = 0; c < comps.Length; c++)
                {
                    if (comps[c] == null) continue;
                    string cn = comps[c].GetType().Name;
                    string cnl = cn.ToLower();
                    if (!cnl.StartsWith("unity") && !cnl.Contains("sprite") && !cnl.Contains("animator")) { compNames += " " + cn; hasCustomScript = true; }
                }

                string combined = (low + " " + compNames.ToLower());
                if (!string.IsNullOrEmpty(fl) && !combined.Contains(fl)) continue;

                bool isQuest = combined.Contains("quest") || combined.Contains("task") || combined.Contains("recipe") ||
                               combined.Contains("mapo") || combined.Contains("tofu") || combined.Contains("cat") ||
                               combined.Contains("thief") || combined.Contains("chest") || combined.Contains("treasure") ||
                               combined.Contains("box") || combined.Contains("relic") || combined.Contains("fragment") ||
                               combined.Contains("goddess") || combined.Contains("key") || combined.Contains("letter") ||
                               combined.Contains("book") || combined.Contains("baoxiang") || combined.Contains("renwu");

                bool isNpc = combined.Contains("npc") || combined.Contains("girl") || combined.Contains("ashley") ||
                             combined.Contains("villager") || combined.Contains("heroine") || combined.Contains("chief");

                bool isItem = combined.Contains("item") || combined.Contains("pick") || combined.Contains("drop") ||
                              combined.Contains("wood") || combined.Contains("tree") || combined.Contains("stone") ||
                              combined.Contains("rock") || combined.Contains("ore") || combined.Contains("iron") ||
                              combined.Contains("herb") || combined.Contains("flower") || combined.Contains("plant") ||
                              combined.Contains("shell") || combined.Contains("fish") || combined.Contains("collect") ||
                              combined.Contains("gather") || combined.Contains("prop") || combined.Contains("interact");

                if (isQuest || isNpc || isItem || (hasCustomScript && go.GetComponent("Collider2D") != null))
                {
                    EspNode node = new EspNode();
                    node.Trans = go.transform;
                    node.IsQuestTarget = isQuest;
                    node.IsNpc = isNpc;
                    node.Color = isQuest ? new Color(1f, 0.78f, 0.1f, 0.95f) : (isNpc ? new Color(1f, 0.45f, 0.85f, 0.95f) : new Color(0.25f, 1f, 0.5f, 0.9f));
                    node.VietName = (isQuest ? "[NHIEM VU] " : (isNpc ? "[NPC] " : "[VAT PHAM] ")) + TranslateToViet(n + compNames, 0);
                    _espNodes.Add(node);
                    if (_espNodes.Count >= 80) break;
                }
            }
        }

        private void DrawEspOverlay()
        {
            Camera cam = Camera.main;
            if (cam == null && Camera.allCamerasCount > 0) cam = Camera.allCameras[0];
            if (cam == null) return;

            Vector2 center = new Vector2(Screen.width * 0.5f, Screen.height * 0.5f);
            Transform pt = FindPlayerTransform();

            for (int i = 0; i < _espNodes.Count; i++)
            {
                EspNode en = _espNodes[i];
                if (en.Trans == null) continue;
                Vector3 wp = en.Trans.position;
                Vector3 sp = cam.WorldToScreenPoint(wp);
                if (sp.z < 0f) continue;

                float gx = Mathf.Clamp(sp.x, 30f, Screen.width - 30f);
                float gy = Mathf.Clamp(Screen.height - sp.y, 30f, Screen.height - 30f);
                float dist = pt != null ? Vector2.Distance(pt.position, wp) : 0f;

                if (_espLines) DrawLine(center, new Vector2(gx, gy), en.Color, en.IsQuestTarget ? 2.2f : 1.2f);

                string txt = string.Format("{0} [{1:F1}m]", en.VietName, dist);
                Rect r = new Rect(gx - 130f, gy - 25f, 260f, 22f);
                Color prev = GUI.color;
                GUI.color = Color.black;
                GUI.Label(new Rect(r.x + 1f, r.y + 1f, r.width, r.height), txt, _espStyle);
                GUI.color = en.Color;
                GUI.Label(r, txt, _espStyle);
                GUI.color = prev;
            }
        }

        private void DrawLine(Vector2 p1, Vector2 p2, Color col, float width)
        {
            Vector2 d = p2 - p1;
            float len = d.magnitude;
            if (len < 2f) return;
            Color prevC = GUI.color;
            Matrix4x4 prevM = GUI.matrix;
            GUI.color = col;
            float angle = Mathf.Atan2(d.y, d.x) * Mathf.Rad2Deg;
            GUIUtility.RotateAroundPivot(angle, p1);
            GUI.DrawTexture(new Rect(p1.x, p1.y - width * 0.5f, len, width), _whiteTex);
            GUI.matrix = prevM;
            GUI.color = prevC;
        }

        private Transform FindPlayerTransform()
        {
            GameObject p = GameObject.FindWithTag("Player");
            if (p != null) return p.transform;
            GameObject[] all = UnityEngine.Object.FindObjectsOfType<GameObject>();
            for (int i = 0; i < all.Length; i++)
            {
                if (all[i] != null && all[i].activeInHierarchy)
                {
                    string n = all[i].name.ToLower();
                    if (n == "player" || n == "ron" || n.Contains("playercontroller") || n.Contains("hero")) return all[i].transform;
                }
            }
            return null;
        }

        private void TeleportPlayerTo(Vector3 targetPos)
        {
            Transform pt = FindPlayerTransform();
            if (pt != null) { pt.position = new Vector3(targetPos.x, targetPos.y, pt.position.z); _status = "Da dich chuyen!"; }
            else _status = "Khong tim thay Player!";
        }

        private void PullTransformToPlayer(Transform target)
        {
            if (target == null) return;
            Transform pt = FindPlayerTransform();
            Vector3 dest = pt != null ? pt.position : (Camera.main != null ? Camera.main.transform.position : Vector3.zero);
            target.position = new Vector3(dest.x, dest.y, target.position.z);
            _status = "Da keo [" + target.name + "] ve chan!";
        }

        private void PullAllItemsOnMapToPlayer()
        {
            ScanEspTargets();
            Transform pt = FindPlayerTransform();
            Vector3 dest = pt != null ? pt.position : (Camera.main != null ? Camera.main.transform.position : Vector3.zero);
            int pulled = 0;
            for (int i = 0; i < _espNodes.Count; i++)
            {
                if (_espNodes[i].Trans != null && !_espNodes[i].IsNpc)
                {
                    _espNodes[i].Trans.position = new Vector3(dest.x, dest.y, _espNodes[i].Trans.position.z);
                    pulled++;
                }
            }
            _status = "Da hut " + pulled + " vat pham ve chan!";
        }

        private void Apply4KGraphics()
        {
            Screen.SetResolution(3840, 2160, FullScreenMode.FullScreenWindow);
            int maxQ = QualitySettings.names.Length - 1;
            if (maxQ >= 0) QualitySettings.SetQualityLevel(maxQ, true);
            QualitySettings.masterTextureLimit = 0;
            QualitySettings.antiAliasing = 8;
            QualitySettings.anisotropicFiltering = AnisotropicFiltering.ForceEnable;
            Texture[] texs = Resources.FindObjectsOfTypeAll<Texture>();
            for (int i = 0; i < texs.Length; i++)
            {
                if (texs[i] != null)
                {
                    texs[i].filterMode = FilterMode.Trilinear;
                    texs[i].anisoLevel = 16;
                    Texture2D t2d = texs[i] as Texture2D;
                    if (t2d != null) t2d.mipMapBias = -1.0f;
                }
            }
            _status = "Da bat 4K Ultra!";
        }

        private void ToggleUI()
        {
            _hideUi = !_hideUi;
            if (_hideUi)
            {
                _hiddenCanvases.Clear();
                Canvas[] list = UnityEngine.Object.FindObjectsOfType<Canvas>();
                for (int i = 0; i < list.Length; i++)
                {
                    if (list[i].enabled) { list[i].enabled = false; _hiddenCanvases.Add(list[i]); }
                }
            }
            else
            {
                for (int i = 0; i < _hiddenCanvases.Count; i++) { if (_hiddenCanvases[i] != null) _hiddenCanvases[i].enabled = true; }
                _hiddenCanvases.Clear();
            }
        }

        private string TranslateToViet(string raw, int id)
        {
            string clean = raw.Replace("(Clone)", "").Trim();
            string low = clean.ToLower();
            if (low.Contains("cat") || low.Contains("mao") || low.Contains("thief")) return "Meo An Trom / Nhiem Vu (" + clean + ")";
            if (low.Contains("recipe") || low.Contains("shipu") || low.Contains("mapo") || low.Contains("tofu")) return "Cong Thuc Nau An Bi Mat (" + clean + ")";
            if (low.Contains("chest") || low.Contains("treasure") || low.Contains("baoxiang") || low.Contains("box")) return "Ruong Kho Bau (" + clean + ")";
            if (low.Contains("fragment") || low.Contains("goddess") || low.Contains("relic") || low.Contains("suipian")) return "Manh Nu Than / Co Vat (" + clean + ")";
            if (low.Contains("wood") || low.Contains("tree") || low.Contains("log") || low.Contains("mucai")) return "Go / Cay (" + clean + ")";
            if (low.Contains("stone") || low.Contains("rock") || low.Contains("ore") || low.Contains("shitou")) return "Da / Quang (" + clean + ")";
            if (low.Contains("iron") || low.Contains("metal") || low.Contains("tie")) return "Sat / Kim Loai (" + clean + ")";
            if (low.Contains("herb") || low.Contains("flower") || low.Contains("grass") || low.Contains("plant")) return "Thao Duoc / Hoa (" + clean + ")";
            if (low.Contains("shell") || low.Contains("pearl") || low.Contains("coral") || low.Contains("beike")) return "Vo So / Ngoc Trai (" + clean + ")";
            if (low.Contains("fish") || low.Contains("crab") || low.Contains("shrimp")) return "Ca / Hai San (" + clean + ")";
            if (low.Contains("key") || low.Contains("letter") || low.Contains("book")) return "Vat Pham Manh Moi (" + clean + ")";
            return clean;
        }

        private bool IsNumericOrBool(Type t) { return IsNumericType(t) || t == typeof(bool); }
        private bool IsNumericType(Type t) { return t == typeof(int) || t == typeof(long) || t == typeof(short) || t == typeof(byte) || t == typeof(float) || t == typeof(double); }
    }
}
