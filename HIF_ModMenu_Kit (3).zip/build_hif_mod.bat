@echo off
setlocal
cd /d "%~dp0"

echo ========================================================
echo   Happy Island Fantasy Mod Menu - Auto Compiler
echo ========================================================

if not exist "BepInEx\core\BepInEx.dll" (
    echo [LOI] Khong tim thay BepInEx\core\BepInEx.dll! Hay de file nay cung cho voi thu muc BepInEx.
    pause
    exit /b 1
)

set MANAGED=
for /d %%D in (*_Data) do (
    if exist "%%D\Managed\UnityEngine.CoreModule.dll" (
        set MANAGED=%%D\Managed
    )
)

if "%MANAGED%"=="" (
    echo [LOI] Khong tim thay thu muc *_Data\Managed!
    pause
    exit /b 1
)

set CSC=%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\csc.exe
if not exist "%CSC%" (
    set CSC=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\csc.exe
)

if not exist "%CSC%" (
    echo [LOI] Khong tim thay trinh bien dich csc.exe cua Windows!
    pause
    exit /b 1
)

if not exist "BepInEx\plugins" mkdir "BepInEx\plugins"

echo Tim thay thu muc game: %MANAGED%
echo Dang bien dich HIF_ModMenu.cs sang BepInEx\plugins\HIF_ModMenu.dll ...

set REFS=/r:"BepInEx\core\BepInEx.dll" /r:"BepInEx\core\0Harmony.dll"
set REFS=%REFS% /r:"%MANAGED%\UnityEngine.dll"
set REFS=%REFS% /r:"%MANAGED%\UnityEngine.CoreModule.dll"
if exist "%MANAGED%\UnityEngine.IMGUIModule.dll" set REFS=%REFS% /r:"%MANAGED%\UnityEngine.IMGUIModule.dll"
if exist "%MANAGED%\UnityEngine.InputLegacyModule.dll" set REFS=%REFS% /r:"%MANAGED%\UnityEngine.InputLegacyModule.dll"
if exist "%MANAGED%\UnityEngine.TextRenderingModule.dll" set REFS=%REFS% /r:"%MANAGED%\UnityEngine.TextRenderingModule.dll"
if exist "%MANAGED%\UnityEngine.UI.dll" set REFS=%REFS% /r:"%MANAGED%\UnityEngine.UI.dll"
if exist "%MANAGED%\UnityEngine.UIModule.dll" set REFS=%REFS% /r:"%MANAGED%\UnityEngine.UIModule.dll"
if exist "%MANAGED%\UnityEngine.Physics2DModule.dll" set REFS=%REFS% /r:"%MANAGED%\UnityEngine.Physics2DModule.dll"
if exist "%MANAGED%\UnityEngine.PhysicsModule.dll" set REFS=%REFS% /r:"%MANAGED%\UnityEngine.PhysicsModule.dll"

"%CSC%" /target:library /optimize /utf8output /out:"BepInEx\plugins\HIF_ModMenu.dll" %REFS% "HIF_ModMenu.cs"

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [THAT BAI] Bien dich bi loi! Hay chup anh man hinh gui lai cho minh nhe.
    pause
    exit /b 1
)

echo.
echo [THANH CONG] Da tao file BepInEx\plugins\HIF_ModMenu.dll!
echo Hay mo game Happy Island Fantasy va nhan F9 de mo Mod Menu (F7 bat ESP).
pause
